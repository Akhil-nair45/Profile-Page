package com.einfochips.practicedatajpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticedatajpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticedatajpaApplication.class, args);
	}

}
