package com.einfochips.practicedatajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticedatajpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
