package com.einfochips.demodatajpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemodatajpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemodatajpaApplication.class, args);
	}

}
